This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.

Paypal account for donation : http://www.paypal.me/FallenGraphic

purchase full version and commercial license Please contact us : vavaaryanto666@gmail.com 

# INDONESIA - MOHON DIBACA: 
Halo, buat agency, designer, youtuber, atau siapa saja yang ingin menggunakan
font ini untuk kebutuhan KOMERSIL seperti poster filem, pamflet promo, logo perusahaan, kaos,    
dan sejenisnya bisa langsung membeli lisensinya di saya,
silahkan hubungi lewat email saya di : 
vavaaryanto666@gmail.com 

TENANG, harga bersahabat kok :)

Terima kasih